package com.example.humor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HumorApplication {

    public static void main(String[] args) {
        SpringApplication.run(HumorApplication.class, args);
    }
}